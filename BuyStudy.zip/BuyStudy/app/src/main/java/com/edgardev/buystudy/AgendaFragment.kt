package com.edgardev.buystudy

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import com.edgardev.buystudy.databinding.FragmentAgendaBinding

class AgendaFragment : Fragment() {

    private lateinit var binding: FragmentAgendaBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentAgendaBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnAgregarPlanCompra.setOnClickListener {
            val builder = AlertDialog.Builder(view.context)
            val formPlan = LayoutInflater.from(view.context).inflate(R.layout.cardview_form_planes, null)

            builder.setView(formPlan)

            val dialog = builder.create()
            dialog.show()
        }

        binding.btnAgregarNotas.setOnClickListener {
            val builder = AlertDialog.Builder(view.context)
            val dialogView = LayoutInflater.from(view.context).inflate(R.layout.cardview_form_notas, null)

            builder.setView(dialogView)

            val dialog = builder.create()
            dialog.show()

            val nota = dialogView.findViewById<EditText>(R.id.editTextNota)
            val fecha = dialogView.findViewById<EditText>(R.id.editTextFechaNota)
            val btnGuardar = dialogView.findViewById<Button>(R.id.btnGuardarNota)
            val cajaNota = nota
            val cajaNotaFecha = fecha

            btnGuardar.setOnClickListener {

            }
        }
    }
}
