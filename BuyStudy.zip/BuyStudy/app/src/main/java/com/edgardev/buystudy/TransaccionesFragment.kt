package com.edgardev.buystudy

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView

class TransaccionesFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_transacciones, container, false)

        val spinnerType: Spinner = view.findViewById(R.id.spinnerType)
        val spinnerCategory: Spinner = view.findViewById(R.id.spinnerCategoryGastos)
        val spinnerCategoryIngreso: Spinner = view.findViewById(R.id.spinnerCategoryIngreso)
        val titCategoria: TextView = view.findViewById(R.id.titCategoria)

        // Adaptador para el spinner de tipo (Ingresos/Gastos)
        ArrayAdapter.createFromResource(
            requireContext(),
            R.array.transaction_types,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinnerType.adapter = adapter
        }

        // Listener para el spinner de tipo
        spinnerType.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parentView: AdapterView<*>?, selectedItemView: View?, position: Int, id: Long) {
                val selectedType = parentView?.getItemAtPosition(position).toString()

                // Si la opción seleccionada es "Gastos", muestra el spinner de categorías
                if (selectedType == "Gastos") {
                    spinnerCategory.visibility = View.VISIBLE
                    spinnerCategoryIngreso.visibility = View.GONE
                } else {
                    spinnerCategory.visibility = View.GONE
                    spinnerCategoryIngreso.visibility = View.VISIBLE
                }
            }

            override fun onNothingSelected(parentView: AdapterView<*>?) {
                // No es necesario implementar nada aquí
            }
        }

        return view
    }
}
